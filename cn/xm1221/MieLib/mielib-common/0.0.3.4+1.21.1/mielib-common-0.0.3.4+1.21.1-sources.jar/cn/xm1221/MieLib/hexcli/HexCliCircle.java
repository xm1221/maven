package cn.xm1221.MieLib.hexcli;

import at.petrak.hexcasting.api.block.circle.BlockAbstractImpetus;
import at.petrak.hexcasting.api.casting.circles.BlockEntityAbstractImpetus;
import at.petrak.hexcasting.api.casting.circles.CircleExecutionState;
import at.petrak.hexcasting.api.casting.eval.CastingEnvironment;
import at.petrak.hexcasting.api.casting.eval.env.CircleCastEnv;
import at.petrak.hexcasting.api.misc.Result;
import at.petrak.hexcasting.api.pigment.FrozenPigment;
import at.petrak.hexcasting.common.blocks.circles.BlockSlate;
import at.petrak.hexcasting.common.lib.HexBlocks;
import cn.xm1221.MieLib.hexcli.api.HexCliEnvContext;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2738;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

/**
 * {@code mielib:unowned_circle} / {@code mielib:circle}：本体的 {@link CircleCastEnv}。
 * <p>
 * 在锚点处搭一个最小的真实法术环（朝东的红石促动石 + 3 块平放的石板围成 2×2 的环），
 * 用本体的 {@link CircleExecutionState#createNew} 生成执行状态，再按本体的方式构造 CircleCastEnv。
 * {@code mielib:circle}（casters=PLAYER）会把当前假玩家作为环的 caster/head 传进 {@code createNew}；
 * {@code mielib:unowned_circle}（casters=NONE）传 {@code null}。
 * 环只搭一次，之后复用（被破坏了就重搭）。法术环不会被“启动”，HexCLI 直接拿这个环境跑命令里的代码。
 */
public final class HexCliCircle {
    private HexCliCircle() {
    }

    public static CastingEnvironment createEnv(HexCliEnvContext ctx) {
        class_3218 level = ctx.level();
        class_2338 origin = class_2338.method_49638(ctx.anchor());
        class_3222 head = ctx.caster() instanceof class_3222 p ? p : null;
        BlockEntityAbstractImpetus impetus = ensureCircle(level, origin);
        CircleExecutionState state = stateOf(impetus, head);
        if (state == null) {
            // 可能被改坏了：重搭一次
            build(level, origin);
            impetus = impetusAt(level, origin);
            state = impetus == null ? null : stateOf(impetus, head);
            if (state == null)
                throw new IllegalArgumentException("could not build the HexCLI test circle at " + origin.method_23854()
                    + " in " + level.method_27983().method_29177());
        }
        FrozenPigment pig = ctx.session().profilePigment(); // session() 是 @ApiStatus.Internal，HexCLI 自己的代码可以用
        if (pig != null) impetus.setPigment(pig);
        impetus.clearDisplay();
        return new CircleCastEnv(level, state);
    }

    private static @Nullable CircleExecutionState stateOf(BlockEntityAbstractImpetus impetus,
            @Nullable class_3222 caster) {
        Result<CircleExecutionState, class_2338> r = CircleExecutionState.createNew(impetus, caster);
        return r instanceof Result.Ok<CircleExecutionState, class_2338> ok ? ok.ok : null;
    }

    private static BlockEntityAbstractImpetus ensureCircle(class_3218 level, class_2338 origin) {
        BlockEntityAbstractImpetus imp = impetusAt(level, origin);
        if (imp != null) return imp;
        build(level, origin);
        imp = impetusAt(level, origin);
        if (imp == null)
            throw new IllegalArgumentException("could not place the HexCLI test impetus at " + origin.method_23854());
        return imp;
    }

    private static @Nullable BlockEntityAbstractImpetus impetusAt(class_3218 level, class_2338 pos) {
        return level.method_8321(pos) instanceof BlockEntityAbstractImpetus i ? i : null;
    }

    /** 促动石朝东；石板平放在地上（法线朝上），东 → 东南 → 南 → 回到促动石（从南往北进入）。 */
    private static void build(class_3218 level, class_2338 origin) {
        int flags = 2 | 16;
        level.method_8652(origin, HexBlocks.IMPETUS_REDSTONE.get().method_9564()
            .method_11657(BlockAbstractImpetus.FACING, class_2350.field_11034), flags);
        class_2680 slate = HexBlocks.SLATE.get().method_9564().method_11657(BlockSlate.ATTACH_FACE, class_2738.field_12475);
        level.method_8652(origin.method_10078(), slate, flags);
        level.method_8652(origin.method_10078().method_10072(), slate, flags);
        level.method_8652(origin.method_10072(), slate, flags);
    }

    /** 取出（并清空）促动石上显示的文字：法术环环境里 print 和事故都显示在这。 */
    public static @Nullable String takeDisplay(CastingEnvironment env) {
        if (!(env instanceof CircleCastEnv c)) return null;
        BlockEntityAbstractImpetus imp = c.getImpetus();
        if (imp == null) return null;
        class_2561 msg = imp.getDisplayMsg();
        imp.clearDisplay();
        return msg == null ? null : msg.getString();
    }
}
