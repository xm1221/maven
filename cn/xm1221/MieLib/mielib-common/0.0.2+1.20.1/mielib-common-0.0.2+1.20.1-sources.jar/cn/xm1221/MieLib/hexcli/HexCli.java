package cn.xm1221.MieLib.hexcli;

import cn.xm1221.MieLib.hexcli.HexCliProfiles.ProfileException;
import cn.xm1221.MieLib.hexcli.api.HexCliAPI;
import cn.xm1221.MieLib.hexcli.remote.HexCliOps;
import cn.xm1221.MieLib.hexcli.remote.HexCliRemote;
import cn.xm1221.MieLib.hexcli.remote.HexCliReply;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import dev.architectury.event.events.common.CommandRegistrationEvent;
import dev.architectury.event.events.common.LifecycleEvent;
import dev.architectury.event.events.common.TickEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2179;
import net.minecraft.class_2186;
import net.minecraft.class_2300;
import net.minecraft.class_2303;
import net.minecraft.class_241;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_6880;
import net.minecraft.class_7157;
import net.minecraft.class_7733;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * HexCLI 入口（MieLib 的一部分，默认关闭）。命令只需控制台权限，不需要玩家：
 * <ul>
 *   <li>{@code hexcli run <hexParse 代码>}：在会话 VM 里执行，打印栈 / 渡鸦之思 / 事故 / 媒质</li>
 *   <li>{@code > <代码>}：控制台快捷写法，等同 hexcli run</li>
 *   <li>{@code hexcli stack} / {@code hexcli reset}</li>
 *   <li>{@code hexcli tick <n>}：让时间走 n tick，汇报期间服务器上的其它施法</li>
 *   <li>{@code hexcli wait [quiet] [timeout]}：等到连续 quiet tick 没有任何施法（或超时）</li>
 * </ul>
 * 开关见 {@link HexCliConfig}：{@code -Dmielib.hexcli=true} 或 MieLib 服务端配置 {@code enableHexCli}。
 */
public final class HexCli {
    public static final Logger LOGGER = LoggerFactory.getLogger("HexCLI");

    /** 是否真正启用（{@link #init()} 判定一次；关闭或 hexParse 缺失时保持 false）。 */
    private static boolean active = false;

    private HexCli() {
    }

    /** 由 {@code Mielib.init()} 调用；默认什么都不注册（见 {@link HexCliConfig}）。 */
    public static void init() {
        if (!HexCliConfig.isEnabled()) {
            LOGGER.info("[HexCLI] disabled (enable with -Dmielib.hexcli=true or enableHexCli=true in the MieLib server config)");
            return;
        }
        if (!HexCliConfig.isHexParseLoaded()) {
            LOGGER.error("[HexCLI] enabled but hexParse is not installed; HexCLI stays off");
            return;
        }
        CastObserver.init();
        CommandRegistrationEvent.EVENT.register((dispatcher, registry, selection) -> register(dispatcher, registry));
        LifecycleEvent.SERVER_STARTED.register(server -> {
            CastObserver.bindServer(server);
            MishapPreload.preload();
            HexCliProfiles.writeExamples(server);
            HexCliSession session = HexCliSession.get(server);
            try {
                for (String l : session.applyProfile("default")) LOGGER.info(l);
            } catch (ProfileException e) {
                LOGGER.error("[HexCLI] could not apply default profile: {}", e.getMessage());
            }
            HexCliRemote.start(server);
        });
        LifecycleEvent.SERVER_STOPPING.register(server -> {
            HexCliRemote.stop();
            HexCliOps.clearWaiters();
            CastObserver.shutdown();
            HexCliSession.drop();
        });
        TickEvent.SERVER_POST.register(HexCliOps::tickWaiters);
        active = true;
        LOGGER.info("HexCLI loaded. Try: hexcli run 1 2 add   (or: > 1 2 add)");
    }

    /** HexCLI 是否已启用并注册了命令 / 事件（控制台 {@code >} 改写等据此判断）。 */
    public static boolean isActive() {
        return active;
    }

    private static void register(CommandDispatcher<class_2168> d, class_7157 build) {
        d.register(class_2170.method_9247("hexcli").requires(s -> s.method_9259(2))
            .then(class_2170.method_9247("profile")
                .then(class_2170.method_9247("list").executes(HexCli::profileList))
                .then(class_2170.method_9247("show").executes(HexCli::profileShow))
                .then(class_2170.method_9247("use").then(class_2170.method_9244("name", StringArgumentType.word())
                    .suggests((c, b) -> class_2172.method_9265(HexCliProfiles.list(c.getSource().method_9211()), b))
                    .executes(c -> profileUse(c, StringArgumentType.getString(c, "name"))))))
            .then(class_2170.method_9247("env")
                .then(class_2170.method_9247("list").executes(HexCli::envList))
                .then(class_2170.method_9247("use")
                    .then(class_2170.method_9247("auto").executes(c -> envUse(c, null)))
                    .then(class_2170.method_9244("id", StringArgumentType.greedyString()) // word() 不收 ':'
                        .suggests((c, b) -> {
                            List<String> ids = new ArrayList<>();
                            ids.add("auto");
                            for (class_2960 rl : HexCliAPI.envs().keySet()) ids.add(rl.toString());
                            return class_2172.method_9265(ids, b);
                        })
                        .executes(c -> envUse(c, StringArgumentType.getString(c, "id"))))))
            .then(class_2170.method_9247("caster")
                .then(class_2170.method_9247("player").executes(c -> casterSet(c, "player", null)))
                .then(class_2170.method_9247("none").executes(c -> casterSet(c, "none", null)))
                .then(class_2170.method_9247("select").then(class_2170.method_9244("target", class_2186.method_9309())
                    .executes(c -> casterSet(c, "select", class_2186.method_9313(c, "target")))))
                .then(class_2170.method_9247("summon").then(class_2170.method_9244("entity", class_7733.method_45603(build, class_7924.field_41266))
                    .executes(c -> casterSummon(c, null))
                    .then(class_2170.method_9244("nbt", class_2179.method_9284())
                        .executes(c -> casterSummon(c, class_2179.method_9285(c, "nbt")))))))
            .then(class_2170.method_9247("world").then(class_2170.method_9247("summon")
                .then(class_2170.method_9244("entity", class_7733.method_45603(build, class_7924.field_41266))
                    .then(class_2170.method_9244("tag", StringArgumentType.word())
                        .executes(c -> worldSummon(c, null))
                        .then(class_2170.method_9244("nbt", class_2179.method_9284())
                            .executes(c -> worldSummon(c, class_2179.method_9285(c, "nbt"))))))))
            .then(class_2170.method_9247("media").then(class_2170.method_9244("amount", StringArgumentType.word())
                .suggests((c, b) -> class_2172.method_9265(List.of("infinite", "10000", "100000"), b))
                .executes(c -> media(c, StringArgumentType.getString(c, "amount")))))
            .then(class_2170.method_9247("run").then(class_2170.method_9244("code", StringArgumentType.greedyString())
                .executes(c -> run(c, StringArgumentType.getString(c, "code")))))
            .then(class_2170.method_9247("stack").executes(HexCli::stack))
            .then(class_2170.method_9247("reset").executes(HexCli::reset))
            .then(class_2170.method_9247("tick").then(class_2170.method_9244("ticks", IntegerArgumentType.integer(1, 12000))
                .executes(c -> waitFor(c, IntegerArgumentType.getInteger(c, "ticks"), -1))))
            .then(class_2170.method_9247("wait")
                .executes(c -> waitFor(c, 600, 20))
                .then(class_2170.method_9244("quiet", IntegerArgumentType.integer(1, 1200))
                    .executes(c -> waitFor(c, 600, IntegerArgumentType.getInteger(c, "quiet")))
                    .then(class_2170.method_9244("timeout", IntegerArgumentType.integer(1, 12000))
                        .executes(c -> waitFor(c, IntegerArgumentType.getInteger(c, "timeout"),
                            IntegerArgumentType.getInteger(c, "quiet")))))));
    }

    private static void say(class_2168 src, List<String> lines) {
        // 控制台源会把 sendSuccess 打进服务器日志；一行一条，方便 grep
        for (String l : lines) src.method_9226(() -> class_2561.method_43470(l), false);
    }

    private static int reply(CommandContext<class_2168> ctx, HexCliReply reply) {
        say(ctx.getSource(), reply.lines());
        return reply.ok() ? 1 : 0;
    }

    private static int run(CommandContext<class_2168> ctx, String code) {
        return reply(ctx, HexCliOps.run(ctx.getSource().method_9211(), code));
    }

    private static int stack(CommandContext<class_2168> ctx) {
        return reply(ctx, HexCliOps.stack(ctx.getSource().method_9211()));
    }

    private static int reset(CommandContext<class_2168> ctx) {
        return reply(ctx, HexCliOps.reset(ctx.getSource().method_9211()));
    }

    // ---- profile / caster / world / media ----

    private static int profileList(CommandContext<class_2168> ctx) {
        return reply(ctx, HexCliOps.profileList(ctx.getSource().method_9211()));
    }

    private static int profileShow(CommandContext<class_2168> ctx) {
        return reply(ctx, HexCliOps.profileShow(ctx.getSource().method_9211()));
    }

    private static int profileUse(CommandContext<class_2168> ctx, String name) {
        return reply(ctx, HexCliOps.profileUse(ctx.getSource().method_9211(), name));
    }

    private static int envList(CommandContext<class_2168> ctx) {
        return reply(ctx, HexCliOps.envList(ctx.getSource().method_9211()));
    }

    private static int envUse(CommandContext<class_2168> ctx, @org.jetbrains.annotations.Nullable String raw) {
        return reply(ctx, HexCliOps.envUse(ctx.getSource().method_9211(), raw));
    }

    private static int media(CommandContext<class_2168> ctx, String amount) {
        return reply(ctx, HexCliOps.media(ctx.getSource().method_9211(), amount));
    }

    private static int casterSet(CommandContext<class_2168> ctx, String mode, @org.jetbrains.annotations.Nullable class_1297 target) {
        HexCliSession s = HexCliSession.get(ctx.getSource().method_9211());
        switch (mode) {
            case "player" -> s.setCasterPlayer();
            case "none" -> s.setCasterNone();
            default -> {
                if (!(target instanceof class_1309 le)) {
                    say(ctx.getSource(), List.of("[HexCLI] caster error: " + HexCliSession.describe(target)
                        + " is not a living entity; casters must be LivingEntity"));
                    return 0;
                }
                s.setCaster(le);
            }
        }
        String env;
        try {
            env = s.resolveEnv().toString() + (s.effectiveIsAuto() ? " (auto)" : "");
        } catch (RuntimeException e) {
            env = "? (" + e.getMessage() + ")";
        }
        say(ctx.getSource(), List.of("[HexCLI] caster = " + HexCliSession.describe(s.caster()) + " at " + HexCliSession.fmt(s.anchor())
            + " (env " + env + ")"));
        return 1;
    }

    private static class_1297 summonAt(CommandContext<class_2168> ctx, @org.jetbrains.annotations.Nullable class_2487 nbt, List<String> tags)
        throws CommandSyntaxException {
        HexCliSession s = HexCliSession.get(ctx.getSource().method_9211());
        class_6880.class_6883<class_1299<?>> type = class_7733.method_45610(ctx, "entity");
        return HexCliProfiles.summon(s.level(), type.method_40237().method_29177().toString(), s.anchor(), nbt == null ? null : nbt.toString(), tags);
    }

    private static int casterSummon(CommandContext<class_2168> ctx, @org.jetbrains.annotations.Nullable class_2487 nbt)
        throws CommandSyntaxException {
        try {
            class_1297 e = summonAt(ctx, nbt, List.of(HexCliProfiles.CASTER_TAG));
            if (!(e instanceof class_1309)) {
                e.method_31472();
                say(ctx.getSource(), List.of("[HexCLI] caster error: " + HexCliSession.describe(e) + " is not a living entity"));
                return 0;
            }
            return casterSet(ctx, "select", e);
        } catch (ProfileException e) {
            say(ctx.getSource(), List.of("[HexCLI] summon error: " + e.getMessage()));
            return 0;
        }
    }

    private static int worldSummon(CommandContext<class_2168> ctx, @org.jetbrains.annotations.Nullable class_2487 nbt)
        throws CommandSyntaxException {
        try {
            class_1297 e = summonAt(ctx, nbt, List.of(StringArgumentType.getString(ctx, "tag")));
            say(ctx.getSource(), List.of("[HexCLI] summoned " + HexCliSession.describe(e) + " at " + HexCliSession.fmt(e.method_19538())
                + " tags=" + e.method_5752()));
            return 1;
        } catch (ProfileException e) {
            say(ctx.getSource(), List.of("[HexCLI] summon error: " + e.getMessage()));
            return 0;
        }
    }

    /** 解析原版选择器，要求恰好选中一个 LivingEntity。 */
    static class_1309 selectOne(MinecraftServer server, class_3218 level, String selector) {
        class_2300 sel;
        try {
            sel = new class_2303(new StringReader(selector)).method_9882();
        } catch (CommandSyntaxException e) {
            throw new ProfileException("bad selector '" + selector + "': " + e.getMessage());
        }
        class_2168 src = server.method_3739().method_9227(level).method_9206(4)
            .method_9208(net.minecraft.class_243.method_24955(level.method_43126())).method_9216(class_241.field_1340);
        List<? extends class_1297> found;
        try {
            found = sel.method_9816(src);
        } catch (CommandSyntaxException e) {
            throw new ProfileException("selector '" + selector + "' failed: " + e.getMessage());
        }
        if (found.size() != 1)
            throw new ProfileException("selector '" + selector + "' matched " + found.size() + " entities, need exactly 1");
        if (!(found.get(0) instanceof class_1309 le))
            throw new ProfileException("selector '" + selector + "' matched " + HexCliSession.describe(found.get(0)) + ", which is not a LivingEntity");
        return le;
    }

    // ---- 让时间流逝：tick / wait ----

    private static int waitFor(CommandContext<class_2168> ctx, int timeout, int quiet) {
        class_2168 src = ctx.getSource();
        HexCliReply started = HexCliOps.wait(src.method_9211(), timeout, quiet,
            done -> say(src, done.lines()));
        say(src, started.lines());
        return 1;
    }
}
