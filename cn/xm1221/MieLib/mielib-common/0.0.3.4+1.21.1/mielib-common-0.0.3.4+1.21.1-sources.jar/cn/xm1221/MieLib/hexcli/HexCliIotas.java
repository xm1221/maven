package cn.xm1221.MieLib.hexcli;

import at.petrak.hexcasting.api.casting.iota.EntityIota;
import at.petrak.hexcasting.api.casting.iota.GarbageIota;
import at.petrak.hexcasting.api.casting.iota.Iota;
import at.petrak.hexcasting.api.casting.iota.ListIota;
import at.petrak.hexcasting.xplat.IXplatAbstractions;
import cn.xm1221.MieLib.MieIotas;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5251;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.util.Locale;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * iota 的文本 / JSON 表示。
 * <p>
 * {@link EntityIota#display()} 里带 Inline 的占位组件，控制台会打成 {@code Zombie: .}；
 * 这里对实体 iota 用 {@code <实体 id> "<名字>" @ x, y, z #<uuid 前 8 位>} 代替，列表递归。
 * 控制台输出和远程客户端共用同一套文本，保证两边看到的一样。
 */
public final class HexCliIotas {
    private HexCliIotas() {
    }

    /** 人类可读的一行文本（实体 / 列表已修正）。没有世界时用已记录的服务器 overworld 解析实体。 */
    public static String text(Iota iota) {
        return text(iota, fallbackLevel());
    }

    /** 人类可读的一行文本（实体 / 列表已修正）。 */
    public static String text(Iota iota, @Nullable class_3218 level) {
        if (iota instanceof EntityIota ei) return entityText(ei, level);
        // 本体的垃圾 iota 显示是乱码（obfuscated）文本，终端里看着像真数据
        if (iota instanceof GarbageIota) return "<garbage>";
        if (iota instanceof ListIota li) {
            StringBuilder sb = new StringBuilder("[");
            boolean first = true;
            for (Iota child : li.getList()) {
                if (!first) sb.append(", ");
                sb.append(text(child, level));
                first = false;
            }
            return sb.append(']').toString();
        }
        return safe(() -> iota.display().getString());
    }

    /**
     * 实体 iota 的文本：1.21 的 {@link EntityIota#getEntity(class_3218)} 需要世界，
     * 拿不到实体时退化成 {@code entity "<名字>" #<uuid 前 8 位>}。
     */
    public static String entityText(EntityIota ei, @Nullable class_3218 level) {
        class_1297 e = level == null ? null : safeEntity(() -> ei.getEntity(level));
        if (e != null) return entityText(e);
        String name = safe(() -> ei.getRawName());
        String uuid = safe(() -> ei.getEntityId().toString());
        if (uuid.length() > 8) uuid = uuid.substring(0, 8);
        return String.format(Locale.ROOT, "entity \"%s\" #%s", name, uuid);
    }

    private static @Nullable class_3218 fallbackLevel() {
        MinecraftServer server = MieIotas.getServer();
        return server == null ? null : server.method_30002();
    }

    public static String entityText(class_1297 e) {
        String type = safe(() -> class_7923.field_41177.method_10221(e.method_5864()).toString());
        String name = safe(() -> e.method_5477().getString());
        class_243 p = e.method_19538();
        String uuid = safe(() -> e.method_5667().toString());
        if (uuid.length() > 8) uuid = uuid.substring(0, 8);
        return String.format(Locale.ROOT, "%s \"%s\" @ %.1f, %.1f, %.1f #%s", type, name, p.field_1352, p.field_1351, p.field_1350, uuid);
    }

    /** iota 类型的 id（注册名），拿不到时返回 "unknown"。 */
    public static String typeId(Iota iota) {
        return safe(() -> {
            class_2960 rl = IXplatAbstractions.INSTANCE.getIotaTypeRegistry().method_10221(iota.getType());
            return rl == null ? "unknown" : rl.toString();
        });
    }

    /** 类型颜色 {@code #rrggbb}（IotaType#color，按 tag 计算）。 */
    public static String color(Iota iota) {
        int rgb = safeInt(() -> iota.getType().color(), 0xFFFFFF);
        return String.format(Locale.ROOT, "#%06x", rgb & 0xFFFFFF);
    }

    /**
     * 结构化表示：{@code {"type", "text", "rich", "color", "children"?}}；
     * 实体 iota 另外带 {@code "entity": {"type","name","pos":[x,y,z],"uuid"}}。
     * {@code rich} 是 display() 的带样式分段（实体用修正后的纯文本代替）。
     */
    public static JsonObject toJson(Iota iota) {
        return toJson(iota, fallbackLevel());
    }

    /** 结构化表示；{@code level} 用于解析实体 iota（拿不到实体时省略 {@code entity} 字段）。 */
    public static JsonObject toJson(Iota iota, @Nullable class_3218 level) {
        JsonObject out = new JsonObject();
        out.addProperty("type", typeId(iota));
        out.addProperty("text", text(iota, level));
        out.addProperty("color", color(iota));

        class_2561 display;
        if (iota instanceof EntityIota || iota instanceof GarbageIota) {
            // 同本体：实体 AQUA；垃圾用暗灰（本体是乱码样式）
            display = class_2561.method_43470(text(iota, level)).method_27692(iota instanceof EntityIota
                ? net.minecraft.class_124.field_1075 : net.minecraft.class_124.field_1063);
        } else {
            display = safeComponent(iota::display);
        }
        out.add("rich", rich(display));

        if (iota instanceof EntityIota ei) {
            class_1297 e = level == null ? null : safeEntity(() -> ei.getEntity(level));
            if (e != null) {
                JsonObject ent = new JsonObject();
                ent.addProperty("type", safe(() -> class_7923.field_41177.method_10221(e.method_5864()).toString()));
                ent.addProperty("name", safe(() -> e.method_5477().getString()));
                JsonArray pos = new JsonArray();
                class_243 p = e.method_19538();
                pos.add(p.field_1352);
                pos.add(p.field_1351);
                pos.add(p.field_1350);
                ent.add("pos", pos);
                ent.addProperty("uuid", safe(() -> e.method_5667().toString()));
                out.add("entity", ent);
            } else {
                // 实体不在当前世界：给 uuid / 名字，客户端仍能显示
                JsonObject ent = new JsonObject();
                ent.addProperty("name", safe(() -> ei.getRawName()));
                ent.addProperty("uuid", safe(() -> ei.getEntityId().toString()));
                out.add("entity", ent);
            }
        }
        if (iota instanceof ListIota li) {
            JsonArray children = new JsonArray();
            for (Iota child : li.getList()) children.add(toJson(child, level));
            out.add("children", children);
        }
        return out;
    }

    /** 把 Component 拆成带样式的分段。 */
    public static JsonArray rich(class_2561 component) {
        JsonArray arr = new JsonArray();
        component.method_27658((style, s) -> {
            if (!s.isEmpty()) {
                JsonObject seg = new JsonObject();
                seg.addProperty("text", s);
                class_5251 c = style.method_10973();
                if (c != null) seg.addProperty("color", String.format(Locale.ROOT, "#%06x", c.method_27716() & 0xFFFFFF));
                if (style.method_10984()) seg.addProperty("bold", true);
                if (style.method_10966()) seg.addProperty("italic", true);
                if (style.method_10965()) seg.addProperty("underlined", true);
                if (style.method_10987()) seg.addProperty("obfuscated", true);
                arr.add(seg);
            }
            return Optional.empty();
        }, class_2583.field_24360);
        return arr;
    }

    private static class_2561 safeComponent(Supplier<class_2561> f) {
        try {
            class_2561 c = f.get();
            return c == null ? class_2561.method_43473() : c;
        } catch (Throwable t) {
            return class_2561.method_43470("<" + t.getClass().getSimpleName() + ">");
        }
    }

    private static String safe(Supplier<?> f) {
        try {
            return String.valueOf(f.get());
        } catch (Throwable t) {
            return "<" + t.getClass().getSimpleName() + ">";
        }
    }

    private static @Nullable class_1297 safeEntity(Supplier<class_1297> f) {
        try {
            return f.get();
        } catch (Throwable t) {
            return null;
        }
    }

    private static int safeInt(Supplier<Integer> f, int dflt) {
        try {
            Integer v = f.get();
            return v == null ? dflt : v;
        } catch (Throwable t) {
            return dflt;
        }
    }
}
