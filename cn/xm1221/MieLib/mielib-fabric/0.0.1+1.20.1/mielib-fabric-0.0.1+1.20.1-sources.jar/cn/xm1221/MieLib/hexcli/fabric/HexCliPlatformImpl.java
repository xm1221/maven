package cn.xm1221.MieLib.hexcli.fabric;

import cn.xm1221.MieLib.hexcli.HexCliPlatform;
import com.mojang.authlib.GameProfile;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/** {@link HexCliPlatform} 的 Fabric 实现（Architectury {@code ExpectPlatform}）。 */
public final class HexCliPlatformImpl {
    private HexCliPlatformImpl() {
    }

    public static class_3222 createFakePlayer(class_3218 level, GameProfile profile) {
        return new FabricHexCliPlayer(level, profile);
    }
}
