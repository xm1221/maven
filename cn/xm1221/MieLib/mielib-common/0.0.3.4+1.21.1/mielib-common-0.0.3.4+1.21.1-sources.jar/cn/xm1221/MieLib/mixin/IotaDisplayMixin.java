package cn.xm1221.MieLib.mixin;

import at.petrak.hexcasting.api.casting.iota.Iota;
import cn.xm1221.MieLib.registry.IotaDisplayHook;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_5481;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Client display hook. Hex 0.12 moved iota text onto the instance method {@code Iota.display()},
 * which each subtype overrides, so a mixin on the abstract method would not see those overrides.
 * {@code displayWithMaxWidth} is still concrete on {@link Iota} and is what {@code GuiSpellcasting} calls.
 */
@Mixin(Iota.class)
public abstract class IotaDisplayMixin {

    @WrapMethod(method = "displayWithMaxWidth", remap = false)
    private class_5481 mielib$displayWithMaxWidth(
            int maxWidth, class_327 font, Operation<class_5481> original) {
        Iota self = (Iota) (Object) this;
        if (!IotaDisplayHook.hasWorkersFor(self)) {
            return original.call(maxWidth, font);
        }

        class_2561 base = self.display();
        IotaDisplayHook.IotaDisplayCall result =
                IotaDisplayHook.effect(self, new IotaDisplayHook.IotaDisplayCall(base, null, self.getType()));
        class_2561 display = result.getDisplay();
        if (display == null || display == base) {
            return original.call(maxWidth, font);
        }

        var splitted = font.method_1728(display, maxWidth - font.method_1727("..."));
        if (splitted.isEmpty()) {
            return class_5481.field_26385;
        } else if (splitted.size() == 1) {
            return splitted.get(0);
        } else {
            return class_5481.method_30752(
                    splitted.get(0),
                    class_2561.method_43470("...").method_27692(class_124.field_1080).method_30937());
        }
    }
}
