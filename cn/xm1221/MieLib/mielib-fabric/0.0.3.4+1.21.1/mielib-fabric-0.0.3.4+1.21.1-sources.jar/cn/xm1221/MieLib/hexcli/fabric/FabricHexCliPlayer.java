package cn.xm1221.MieLib.hexcli.fabric;

import cn.xm1221.MieLib.hexcli.HexCliFakePlayer;
import com.mojang.authlib.GameProfile;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import java.util.ArrayList;
import java.util.List;

/**
 * Fabric 侧的 HexCLI 假玩家：和 Fabric 的 {@link FakePlayer} 一样不连网络，
 * 但会把发给它的系统消息（hexParse 的“未知符号”等提示、法术的 chat 输出）收集起来，打印到控制台。
 */
public final class FabricHexCliPlayer extends FakePlayer implements HexCliFakePlayer {
    private final List<String> messages = new ArrayList<>();

    public FabricHexCliPlayer(class_3218 level, GameProfile profile) {
        super(level, profile);
    }

    @Override
    public void method_43496(class_2561 component) {
        method_43502(component, false);
    }

    @Override
    public void method_43502(class_2561 component, boolean overlay) {
        if (!overlay) messages.add(component.getString());
    }

    @Override
    public List<String> drainMessages() {
        List<String> out = new ArrayList<>(messages);
        messages.clear();
        return out;
    }
}
