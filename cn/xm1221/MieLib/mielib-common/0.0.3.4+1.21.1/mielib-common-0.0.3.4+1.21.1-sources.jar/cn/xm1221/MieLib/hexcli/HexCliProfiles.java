package cn.xm1221.MieLib.hexcli;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2522;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;

/** profile 文件读写 + 世界布置（原版命令 / 生成实体）+ 物品 / 实体等小工具。 */
public final class HexCliProfiles {
    public static final String SPAWNED_TAG = "hexcli_spawned";
    public static final String CASTER_TAG = "hexcli_caster";
    static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    private HexCliProfiles() {
    }

    /** 配置出错：消息直接打印给用户。 */
    public static final class ProfileException extends RuntimeException {
        public ProfileException(String msg) {
            super(msg);
        }
    }

    public static Path dir(MinecraftServer server) {
        return server.method_3831().resolve("hexcli").resolve("profiles");
    }

    public static List<String> list(MinecraftServer server) {
        Path d = dir(server);
        if (!Files.isDirectory(d)) return List.of();
        try (Stream<Path> s = Files.list(d)) {
            return s.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".json"))
                .map(n -> n.substring(0, n.length() - 5)).sorted().toList();
        } catch (IOException e) {
            throw new ProfileException("cannot list " + d + ": " + e.getMessage());
        }
    }

    public static HexCliProfile load(MinecraftServer server, String name) {
        if (!name.matches("[A-Za-z0-9_.\\-]+")) throw new ProfileException("bad profile name '" + name + "'");
        Path f = dir(server).resolve(name + ".json");
        if (!Files.isRegularFile(f))
            throw new ProfileException("unknown profile '" + name + "' (no " + f + "); known: " + String.join(", ", list(server)));
        try (Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
            HexCliProfile p = GSON.fromJson(r, HexCliProfile.class);
            if (p == null) p = new HexCliProfile();
            if (p.caster == null) p.caster = new HexCliProfile.Caster();
            return p;
        } catch (JsonParseException | IllegalStateException | NumberFormatException e) {
            throw new ProfileException("bad JSON in " + f + ": " + rootMessage(e));
        } catch (IOException e) {
            throw new ProfileException("cannot read " + f + ": " + e.getMessage());
        }
    }

    public static @Nullable String descriptionOf(MinecraftServer server, String name) {
        try {
            return load(server, name).description;
        } catch (ProfileException e) {
            return "(broken: " + e.getMessage() + ")";
        }
    }

    static String rootMessage(Throwable t) {
        while (t.getCause() != null && t.getCause() != t) t = t.getCause();
        return t.getMessage();
    }

    // ---- 示例 profile ----

    public static void writeExamples(MinecraftServer server) {
        Path d = dir(server);
        try {
            Files.createDirectories(d);
            for (Map.Entry<String, HexCliProfile> e : examples().entrySet()) {
                Path f = d.resolve(e.getKey() + ".json");
                if (!Files.exists(f)) Files.writeString(f, GSON.toJson(e.getValue()) + "\n", StandardCharsets.UTF_8);
            }
        } catch (IOException e) {
            HexCli.LOGGER.error("[HexCLI] cannot write example profiles to {}: {}", d, e.getMessage());
        }
    }

    private static Map<String, HexCliProfile> examples() {
        Map<String, HexCliProfile> m = new LinkedHashMap<>();

        HexCliProfile def = new HexCliProfile();
        def.description = "fake player with an oak staff, enlightened, all great patterns unlocked, infinite media/ambit";
        def.caster.learnedGreatPatterns = List.of("all");
        def.media = new JsonPrimitive("infinite");
        def.ambit = new JsonPrimitive("infinite");
        m.put("default", def);

        HexCliProfile un = new HexCliProfile();
        un.description = "same fake player but NOT enlightened: great spells parse (unlocked) but mishap when cast";
        un.caster.enlightened = false;
        un.caster.learnedGreatPatterns = List.of("all");
        un.media = new JsonPrimitive("infinite");
        un.ambit = new JsonPrimitive("infinite");
        m.put("unenlightened", un);

        HexCliProfile none = new HexCliProfile();
        none.description = "no caster: a real spell circle (redstone impetus + 3 slates) is built at world spawn and the code runs in the base CircleCastEnv; 1 dust budget, ambit 32 blocks around the anchor";
        none.caster.type = "none";
        none.caster.enlightened = true;
        none.media = new JsonPrimitive(10000);
        none.ambit = new JsonPrimitive(32);
        m.put("nocaster", none);

        HexCliProfile st = new HexCliProfile();
        st.description = "fake player starting with stack [1, 2] and ravenmind 42; 1 dust budget";
        st.caster.learnedGreatPatterns = List.of("all");
        st.initialStack = "num_1 num_2";
        st.ravenmind = "num_42";
        st.media = new JsonPrimitive(10000);
        st.ambit = new JsonPrimitive("default");
        HexCliProfile.Stack pg = new HexCliProfile.Stack("hexcasting:dye_colorizer_purple", 1);
        st.pigment = pg;
        m.put("stacked", st);

        HexCliProfile pkg = new HexCliProfile();
        pkg.description = "fake player casting through the cypher in the main hand (env mielib:packaged); infinite media/ambit";
        pkg.env = "mielib:packaged";
        pkg.caster.mainhand = new HexCliProfile.Stack("hexcasting:cypher", 1);
        pkg.caster.learnedGreatPatterns = List.of("all");
        pkg.media = new JsonPrimitive("infinite");
        pkg.ambit = new JsonPrimitive("infinite");
        pkg.envData = new JsonObject();
        pkg.envData.addProperty("hand", "main");
        m.put("packaged", pkg);
        return m;
    }

    // ---- 小工具 ----

    public static class_2960 id(String s, String what) {
        class_2960 rl = class_2960.method_12829(s);
        if (rl == null) throw new ProfileException("bad " + what + " id '" + s + "'");
        return rl;
    }

    public static class_2487 snbt(@Nullable String s, String what) {
        if (s == null || s.isBlank()) return new class_2487();
        try {
            return class_2522.method_10718(s);
        } catch (Exception e) {
            throw new ProfileException("bad SNBT for " + what + " '" + s + "': " + e.getMessage());
        }
    }

    public static class_1799 stack(@Nullable HexCliProfile.Stack s, String what) {
        if (s == null || s.id == null) return class_1799.field_8037;
        class_2960 rl = id(s.id, "item");
        class_1792 item = class_7923.field_41178.method_17966(rl)
            .orElseThrow(() -> new ProfileException("unknown item '" + s.id + "' in " + what));
        class_1799 st = new class_1799(item, Math.max(1, s.count));
        if (s.nbt != null && !s.nbt.isBlank()) st.method_57379(class_9334.field_49628, class_9279.method_57456(snbt(s.nbt, what)));
        return st;
    }

    public static class_243 vec(@Nullable double[] p, class_243 dflt, String what) {
        if (p == null) return dflt;
        if (p.length != 3) throw new ProfileException(what + " must be [x, y, z]");
        return new class_243(p[0], p[1], p[2]);
    }

    /** 和原版 /summon 一样生成实体；加上 hexcli_spawned 和额外标签。 */
    public static class_1297 summon(class_3218 level, String entityId, class_243 pos, @Nullable String nbt, List<String> tags) {
        class_2960 rl = id(entityId, "entity");
        class_1299<?> type = class_7923.field_41177.method_17966(rl)
            .orElseThrow(() -> new ProfileException("unknown entity type '" + entityId + "'"));
        if (!type.method_5896()) throw new ProfileException("entity type '" + entityId + "' cannot be summoned");
        class_2487 tag = snbt(nbt, "entity " + entityId).method_10553();
        tag.method_10582("id", rl.toString());
        class_1297 e = class_1299.method_17842(tag, level, ent -> {
            ent.method_5808(pos.field_1352, pos.field_1351, pos.field_1350, ent.method_36454(), ent.method_36455());
            return ent;
        });
        if (e == null) throw new ProfileException("failed to create entity '" + entityId + "' with nbt " + tag);
        if (e instanceof class_1308 mob && (nbt == null || nbt.isBlank()))
            mob.method_5943(level, level.method_8404(e.method_24515()), class_3730.field_16462, null);
        e.method_5780(SPAWNED_TAG);
        for (String t : tags) e.method_5780(t);
        if (!level.method_30736(e))
            throw new ProfileException("could not add entity '" + entityId + "' (duplicate UUID?)");
        return e;
    }

    /** 清掉之前 HexCLI 生成的所有实体（所有维度）。 */
    public static int killSpawned(MinecraftServer server) {
        int n = 0;
        for (class_3218 l : server.method_3738()) {
            List<class_1297> victims = new ArrayList<>();
            for (class_1297 e : l.method_27909()) if (e.method_5752().contains(SPAWNED_TAG)) victims.add(e);
            for (class_1297 e : victims) {
                e.method_31472();
                n++;
            }
        }
        return n;
    }

    // ---- 原版命令 ----

    /** 以控制台权限 4 在给定维度执行命令；失败时返回收集到的输出，成功返回 null。 */
    public static @Nullable String command(MinecraftServer server, class_3218 level, String cmd) {
        List<String> msgs = new ArrayList<>();
        class_2165 sink = new class_2165() {
            @Override
            public void method_43496(class_2561 c) {
                msgs.add(c.getString());
            }

            @Override
            public boolean method_9200() {
                return false;
            }

            @Override
            public boolean method_9202() {
                return true;
            }
            // sendSuccess 在 acceptsSuccess()=false 时不会到这里，所以 msgs 里只有失败消息

            @Override
            public boolean method_9201() {
                return false;
            }
        };
        class_2168 src = new class_2168(sink, class_243.method_24954(level.method_43126()), class_241.field_1340,
            level, 4, "HexCLI", class_2561.method_43470("HexCLI"), server, null);
        String c = cmd.startsWith("/") ? cmd.substring(1) : cmd;
        // 返回值没法判断成败（weather 返回 -1、gamerule false 返回 0），只看有没有失败消息
        server.method_3734().method_44252(src, c);
        return msgs.isEmpty() ? null : String.join(" | ", msgs);
    }

    /** 应用 world 段；返回给用户看的结果行。 */
    public static List<String> applyWorld(MinecraftServer server, class_3218 level, class_243 anchor, @Nullable HexCliProfile.World w) {
        List<String> out = new ArrayList<>();
        if (w == null) return out;
        List<String> cmds = new ArrayList<>();
        if (w.time != null) cmds.add("time set " + w.time);
        if (w.weather != null) {
            String wt = w.weather.toLowerCase(Locale.ROOT);
            if (!List.of("clear", "rain", "thunder").contains(wt))
                throw new ProfileException("world.weather must be clear/rain/thunder, got '" + w.weather + "'");
            cmds.add("weather " + wt);
        }
        w.gamerules.forEach((k, v) -> cmds.add("gamerule " + k + " " + v));
        for (HexCliProfile.SetBlock sb : w.setblocks)
            cmds.add("setblock " + sb.pos[0] + " " + sb.pos[1] + " " + sb.pos[2] + " " + sb.block);
        for (HexCliProfile.Structure s : w.structures)
            cmds.add("place template " + s.id + " " + s.pos[0] + " " + s.pos[1] + " " + s.pos[2]);
        cmds.addAll(w.commands);
        int ok = 0;
        for (String c : cmds) {
            String err = command(server, level, c);
            if (err == null) ok++;
            else out.add("[HexCLI] world: `" + c + "` failed: " + err);
        }
        int summoned = 0;
        for (HexCliProfile.Summon s : w.summons) {
            try {
                summon(level, s.entity, vec(s.pos, anchor, "world.summons pos"), s.nbt, s.tags);
                summoned++;
            } catch (ProfileException e) {
                out.add("[HexCLI] world: summon " + s.entity + " failed: " + e.getMessage());
            }
        }
        out.add(0, "[HexCLI] world setup: " + ok + "/" + cmds.size() + " commands ok, " + summoned + "/" + w.summons.size() + " summoned");
        return out;
    }
}
